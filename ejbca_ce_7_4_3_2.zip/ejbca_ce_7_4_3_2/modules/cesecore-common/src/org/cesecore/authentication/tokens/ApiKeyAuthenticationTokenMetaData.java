/*************************************************************************
 *                                                                       *
 *  EJBCA Community: The OpenSource Certificate Authority                *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/

// SUBJECT FOR ECA-6877. LEAVE OUT UNTIL FINAL IMPLEMENTATION IS COMPLETE

package org.cesecore.authentication.tokens;
//
//import java.util.Arrays;
//
//import org.cesecore.authorization.user.matchvalues.ApiKeyAccessMatchValue;
//
//
///**
// * Meta data definition and ServiceLoader marker for {@link org.ejbca.core.ejb.authentication.cli.CliAuthenticationToken}.
// * 
// * @version $Id$
// *
// */
//public class ApiKeyAuthenticationTokenMetaData extends AuthenticationTokenMetaDataBase {
//
//    public static final String TOKEN_TYPE = "ApiKeyAuthenticationToken";
//    
//    public ApiKeyAuthenticationTokenMetaData() {
//        super(TOKEN_TYPE, Arrays.asList(ApiKeyAccessMatchValue.values()), true);
//    }
//}