XmlSerializerUnitTest_SimpleMapFast.xml:            Input data for XmlSerializerUnitTest
