"Project";                      "Library Name";                                 "License type(s)";      "License text";                 "Source";                                                               "Comment";
"Azure AD for Java";            "adal4j-1.4.0.jar";                             "MIT";                  "LICENSE";                      "https://github.com/AzureAD/azure-activedirectory-library-for-java/";   "Microsoft Azure Active Directory Authentication Library (ADAL) for Java";
"CSR Validation";			    "csr-validation-0.0.1-SNAPSHOT.jar"				"MIT";                  "LICENSE";   					"https://github.com/microsoft/Intune-Resource-Access/tree/master/src/CsrValidation"; "Microsoft Intune Access Library";
"JSON-java";					"json-20180130.jar";							"JSON";					"LICENSE";  					"https://github.com/stleary/JSON-java";            						"A reference implementation of a JSON package in Java.";
"OAuth 2.0 SDK"; 				"oauth2-oidc-sdk-8.22.jar";						"ALv2";                 "LICENSE-APACHE-2.0";			"https://bitbucket.org/connect2id/oauth-2.0-sdk-with-openid-connect-extensions/"; "OAuth 2.0 SDK with OpenID Connect extensions";


